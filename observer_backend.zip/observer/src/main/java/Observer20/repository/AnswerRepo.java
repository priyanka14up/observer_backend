
package Observer20.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Observer20.Model.Answer;
import Observer20.Model.Response;
@Repository
public interface AnswerRepo extends JpaRepository<Answer, Long>{

	
//	List<Response> findAllBySubmittedBy(String submittedBy);
//	Response findBySubmittedBy(String submittedBy);
	Answer findByQid(Long qid);
	 List<Long> findAllAidBySid(Long sid);
	 List<Answer> findAllBySid(Long sid);
	//Long findAidBySid(Long sid);
	
}
