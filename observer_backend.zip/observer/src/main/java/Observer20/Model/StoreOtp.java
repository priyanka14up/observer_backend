package Observer20.Model;

public class StoreOtp {
	private static int otp;

	public static int getOtp() {
		
		System.out.println("Get Oto"+otp);
		return otp;
	}

	public static void setOtp(int otp) {
		StoreOtp.otp = otp;
		System.out.println("set Oto"+otp);
	}
	

}