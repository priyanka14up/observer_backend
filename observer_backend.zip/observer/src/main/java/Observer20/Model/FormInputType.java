//package Observer20.Model;
//
//public enum FormInputType {
//	 
//		RadioButton,Text,Number
//	}
//

